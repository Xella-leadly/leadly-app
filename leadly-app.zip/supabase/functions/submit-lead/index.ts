import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const FUNCTION_VERSION = "v2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    const whatsapp = typeof body?.whatsapp === "string" ? body.whatsapp.trim() : "";
    const business = typeof body?.business === "string" ? body.business.trim() : "";

    if (!name || !whatsapp || !business) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: name, whatsapp, business." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const plan = body?.plan === "starter" || body?.plan === "pro" ? body.plan : null;
    const message = typeof body?.message === "string" && body.message.trim()
      ? body.message.trim()
      : null;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error } = await supabase
      .from("leads")
      .insert({ name, whatsapp, business, plan, message });

    if (error) {
      return new Response(
        JSON.stringify({ error: "Could not save lead." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ success: true, v: FUNCTION_VERSION }),
      { status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
