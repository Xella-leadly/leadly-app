/*
# Create leads table (single-tenant, no auth)

1. New Tables
- `leads`
  - `id` (uuid, primary key)
  - `name` (text, not null) — visitor's full name
  - `whatsapp` (text, not null) — WhatsApp contact number
  - `business` (text, not null) — what they sell
  - `plan` (text, nullable) — selected plan ('starter' | 'pro')
  - `message` (text, nullable) — optional note
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `leads`.
- Grant INSERT to `anon` + `authenticated` so the public landing page can submit leads via the anon-key client.
- INSERT-only: no public SELECT/UPDATE/DELETE — leads are operator-only (service_role bypasses RLS for the dashboard).
- Anon insert policy uses `WITH CHECK (true)` because the data is intentionally public-write (any visitor can submit a lead).
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  whatsapp text NOT NULL,
  business text NOT NULL,
  plan text CHECK (plan IN ('starter', 'pro')),
  message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON leads TO anon, authenticated;

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads"
  ON leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);