/*
# Lock down leads table: INSERT-only for public, full read/delete for signed-in admins

1. Background
- The `leads` table was created with a single INSERT policy (anon + authenticated, WITH CHECK true).
- It also had table-wide GRANT INSERT only — good — but no SELECT/UPDATE/DELETE grants, so no role could read or remove rows via the Data API.
- We now need: (a) the public landing page to keep submitting leads (INSERT), and (b) a signed-in operator to view and delete leads from the /admin dashboard.

2. Security changes
- Revoke all existing grants on `leads` and re-grant the minimum:
  - `anon` and `authenticated`: INSERT only. Visitors (anon key) can submit leads but cannot read, modify, or delete them.
  - `authenticated`: also SELECT and DELETE, so a signed-in admin can view and remove leads. No UPDATE grant: a lead's content is a record of what the visitor submitted and must not be editable after the fact. If a lead needs to be removed, it is deleted.
- Replace the INSERT policy with a clean one (same effect, idempotent).
- Add a SELECT policy and a DELETE policy for `authenticated` only. Since any signed-in user can read/delete all leads, the operator must control who can sign up — see note 3 below.

3. Important notes
- Auth is required to read leads. The /admin dashboard renders a Supabase email/password sign-in screen before loading any lead data. An unauthenticated visitor hitting /admin sees the sign-in form, not the leads.
- Anyone who can create an account can read all leads. Supabase email/password signup is open by default. If you want to restrict who can sign in, enable "Confirm email" or invite-only signup in the Supabase dashboard Auth settings. For a single-operator admin tool this is usually acceptable, but be aware of it.
- No columns are revoked because INSERT is granted at table level and there is no UPDATE grant at all; the only writable path is INSERT, which the policy guards.
*/

-- Revoke all existing table grants, then re-grant the minimum.
REVOKE ALL ON leads FROM anon, authenticated;

-- Public (anon key on the landing page) and any authenticated user can INSERT a new lead.
GRANT INSERT ON leads TO anon, authenticated;

-- Only signed-in users can read or delete leads (admin dashboard).
GRANT SELECT, DELETE ON leads TO authenticated;

-- INSERT policy: anyone can submit a lead. The data is intentionally public-write.
DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads"
  ON leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- SELECT policy: only signed-in users can read leads. An unauthenticated visitor
-- with the anon key gets zero rows, so the leads cannot be scraped from the public internet.
DROP POLICY IF EXISTS "authenticated_select_leads" ON leads;
CREATE POLICY "authenticated_select_leads"
  ON leads FOR SELECT
  TO authenticated
  USING (true);

-- DELETE policy: only signed-in users can delete leads.
DROP POLICY IF EXISTS "authenticated_delete_leads" ON leads;
CREATE POLICY "authenticated_delete_leads"
  ON leads FOR DELETE
  TO authenticated
  USING (true);
