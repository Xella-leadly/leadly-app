/*
# Add insert_lead RPC function

1. Background
- The sb_publishable_ key returns 201 on direct PostgREST inserts but rows don't persist.
- An edge function was deployed but the gateway also returns 404 with the publishable key.
- A SECURITY DEFINER function called via RPC is the most reliable path: it runs as the
  function owner (postgres), bypasses RLS, and is reachable through the Data API that
  the publishable key CAN reach (auth endpoints already work with this key).

2. New Functions
- `insert_lead(name, whatsapp, business, plan, message)` — inserts a lead and returns the new id.
  SECURITY DEFINER so it runs with owner privileges regardless of caller role.
  This is intentionally public-write (any visitor can submit a lead), matching the existing
  `anon_insert_leads` RLS policy's `WITH CHECK (true)`.

3. Security
- REVOKE EXECUTE from PUBLIC and anon is NOT done here: the function must be callable by the
  anon role (the publishable key's unauthenticated path) so visitors can submit leads.
- The function only performs an INSERT with validated inputs — no SELECT/UPDATE/DELETE — so
  exposing EXECUTE to anon does not leak or modify existing data.
- The `plan` parameter is validated to 'starter' | 'pro' | NULL inside the function body,
  matching the table's CHECK constraint, so callers cannot inject arbitrary values.
*/

CREATE OR REPLACE FUNCTION public.insert_lead(
  p_name text,
  p_whatsapp text,
  p_business text,
  p_plan text DEFAULT NULL,
  p_message text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF p_plan IS NOT NULL AND p_plan NOT IN ('starter', 'pro') THEN
    p_plan := NULL;
  END IF;

  INSERT INTO leads (name, whatsapp, business, plan, message)
  VALUES (p_name, p_whatsapp, p_business, p_plan, p_message)
  RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;
