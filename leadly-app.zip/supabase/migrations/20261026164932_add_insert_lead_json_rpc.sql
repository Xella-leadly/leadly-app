/*
# Add insert_lead_json RPC (single json parameter variant)

1. Background
- PostgREST schema cache hasn't picked up the named-parameter variant of insert_lead.
- Adding a single-json-parameter variant gives PostgREST a simpler signature to match.
- The function validates and inserts the same way.

2. New Functions
- `insert_lead_json(json_body json)` — accepts a single JSON object, inserts a lead, returns id.
- SECURITY DEFINER, public-write (same rationale as insert_lead).
*/

CREATE OR REPLACE FUNCTION public.insert_lead_json(json_body json)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text := trim(coalesce(json_body->>'name', ''));
  v_whatsapp text := trim(coalesce(json_body->>'whatsapp', ''));
  v_business text := trim(coalesce(json_body->>'business', ''));
  v_plan text := json_body->>'plan';
  v_message text := json_body->>'message';
  new_id uuid;
BEGIN
  IF v_name = '' OR v_whatsapp = '' OR v_business = '' THEN
    RAISE EXCEPTION 'Missing required fields';
  END IF;
  IF v_plan IS NOT NULL AND v_plan NOT IN ('starter', 'pro') THEN
    v_plan := NULL;
  END IF;
  IF v_message IS NOT NULL AND btrim(v_message) = '' THEN
    v_message := NULL;
  END IF;

  INSERT INTO leads (name, whatsapp, business, plan, message)
  VALUES (v_name, v_whatsapp, v_business, v_plan, v_message)
  RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;
