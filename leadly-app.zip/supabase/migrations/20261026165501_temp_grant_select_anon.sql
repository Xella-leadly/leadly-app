/*
# Temporarily grant SELECT to anon for insert verification

1. Background
- The sb_publishable_ key returns 201 on inserts but rows don't persist.
- Adding SELECT to anon allows us to use Prefer: return=representation,
  which will return the inserted row in the response body, confirming
  whether the insert is actually happening or being silently discarded.

2. Security
- This is a TEMPORARY diagnostic grant. It will be revoked once we confirm
  the insert behavior. anon SELECT on leads is safe temporarily since the
  table only has 1 row.
*/

GRANT SELECT ON leads TO anon;
